import mongoose from "mongoose";

const MONGODB_URI =
  "mongodb+srv://isaben0406_db_user:isa20200604@cluster0.7d1dqej.mongodb.net/eduplay_db?retryWrites=true&w=majority";

export const connectDB = async () => {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log("MongoDB Atlas conectado exitosamente a eduplay_db 🚀");
  } catch (error) {
    console.error("Error conectando a MongoDB Atlas:", error);
    process.exit(1);
  }
};
